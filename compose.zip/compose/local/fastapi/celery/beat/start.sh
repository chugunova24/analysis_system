#!/bin/bash

set -o errexit

rm -f './celerybeat.pid'
poetry run celery -A backend.src.worker beat -l info
tail -f /dev/null