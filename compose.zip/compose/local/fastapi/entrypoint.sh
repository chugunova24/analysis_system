#!/bin/bash

# if any of the commands in your code fails for any reason, the entire script fails
set -o errexit

